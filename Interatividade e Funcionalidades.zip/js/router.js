
/* router.js - roteador hash simples */
const Router = (function(){
  const routes = {};

  function add(path, action){ routes[path]=action; }

  function resolveRoute(path){
    if(routes[path]) return routes[path]();
    return routes['/']();
  }

  function navigate(hash){
    const path = (hash || '#/').replace('#','');
    const content = resolveRoute(path);
    document.getElementById('app').innerHTML = content;

    // Attaching form listeners when contact view is rendered
    const form = document.getElementById('form-contato');
    if(form){
      form.addEventListener('submit', function(e){
        e.preventDefault();
        const ok = Validation.validateContactForm(form);
        const result = document.getElementById('form-result');
        if(ok){
          // Simulate save and feedback
          result.textContent = 'Mensagem enviada com sucesso. Obrigado!';
          form.reset();
        } else {
          result.textContent = 'Corrija os erros antes de enviar.';
        }
      });
    }
  }

  // Public API
  return { add, navigate };
})();
