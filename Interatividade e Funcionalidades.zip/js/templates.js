
/* templates.js - sistema simples de templates */
const Templates = (function(){
  const tpl = {};

  tpl.home = () => `
    <h1>Bem-vindo à ONG Solidária</h1>
    <p class="small">Gestão de projetos sociais — SPA de demonstração.</p>
    <section class="template-card">
      <h2>Visão geral</h2>
      <p>Este protótipo demonstra: rotas SPA, sistema de templates, e validação de formulários.</p>
    </section>
  `;

  tpl.projetos = (projects=[]) => `
    <h1>Projetos</h1>
    ${projects.length ? projects.map(p=>`<div class="template-card"><strong>${p.titulo}</strong><p class="small">${p.status} — ${p.data_inicio}</p><p>${p.descricao}</p></div>`).join('') : '<p>Nenhum projeto no momento.</p>'}
  `;

  tpl.contato = () => `
    <h1>Fale Conosco</h1>
    <form id="form-contato" novalidate>
      <div class="form-row">
        <label>Nome</label>
        <input type="text" name="nome" id="nome" required />
        <div class="error-msg" data-error-for="nome"></div>
      </div>
      <div class="form-row">
        <label>E-mail</label>
        <input type="email" name="email" id="email" required />
        <div class="error-msg" data-error-for="email"></div>
      </div>
      <div class="form-row">
        <label>Mensagem</label>
        <textarea name="mensagem" id="mensagem" rows="4" required></textarea>
        <div class="error-msg" data-error-for="mensagem"></div>
      </div>
      <button class="btn" type="submit">Enviar</button>
    </form>
    <div id="form-result" style="margin-top:12px"></div>
  `;

  return tpl;
})();
