
/* validation.js - sistema de verificação de consistência em formulários */
const Validation = (function(){
  function setError(el, message){
    el.classList.add('input-error');
    const msg = document.querySelector(`[data-error-for="${el.id}"]`);
    if(msg) msg.textContent = message;
  }
  function clearError(el){
    el.classList.remove('input-error');
    const msg = document.querySelector(`[data-error-for="${el.id}"]`);
    if(msg) msg.textContent = '';
  }

  function validateEmail(value){
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
  }

  function validateContactForm(form){
    let valid = true;
    const nome = form.querySelector('#nome');
    const email = form.querySelector('#email');
    const mensagem = form.querySelector('#mensagem');

    // Nome: mínimo 3 caracteres
    if(!nome.value || nome.value.trim().length < 3){ setError(nome, 'Digite pelo menos 3 caracteres no nome.'); valid = false; } else clearError(nome);

    // Email: formato válido
    if(!email.value || !validateEmail(email.value)){ setError(email, 'Informe um email válido.'); valid = false; } else clearError(email);

    // Mensagem: mínimo 10 caracteres
    if(!mensagem.value || mensagem.value.trim().length < 10){ setError(mensagem, 'A mensagem deve ter ao menos 10 caracteres.'); valid = false; } else clearError(mensagem);

    return valid;
  }

  // Public API
  return {
    validateContactForm
  };
})();
