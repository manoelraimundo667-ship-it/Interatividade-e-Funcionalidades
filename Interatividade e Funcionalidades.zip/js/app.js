
/* app.js - módulo principal */
(function(){
  const sampleProjects = [
    {titulo:'Reforço Escolar', descricao:'Aulas para reforço escolar', data_inicio:'2024-01-10', status:'Ativo'},
    {titulo:'Mutirão de Limpeza', descricao:'Limpeza de praças', data_inicio:'2024-02-20', status:'Ativo'}
  ];

  // Register routes
  Router.add('/', () => Templates.home());
  Router.add('/projetos', () => Templates.projetos(sampleProjects));
  Router.add('/contato', () => Templates.contato());

  // Initial render
  function boot(){
    // Handle links with data-link to use hash navigation
    document.querySelectorAll('[data-link]').forEach(a=>{
      a.addEventListener('click', function(e){ /* nothing here - hash will change */ });
    });

    // Listen to hash changes
    function render(){ Router.navigate(location.hash || '#/'); }
    window.addEventListener('hashchange', render);
    render();
  }

  document.addEventListener('DOMContentLoaded', boot);
})();
