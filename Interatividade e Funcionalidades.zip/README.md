
# Entrega III - Interatividade e Funcionalidades (SPA)

Projeto: Plataforma ONG Solidária - Prototipo SPA

## Estrutura
- index.html
- css/style.css
- js/templates.js (sistema de templates)
- js/validation.js (validações de formulário e consistência de dados)
- js/router.js (roteador hash simples)
- js/app.js (módulo principal)
- assets/logo.png

## Como usar (local)
1. Extraia o ZIP.
2. Abra `index.html` no navegador (recomendado Chrome/Firefox).
3. Navegue entre Home / Projetos / Contato.
4. No formulário de contato, teste validações (nome, email, mensagem).

## Implantação no GitHub Pages
1. Crie repositório no GitHub e envie os arquivos.
2. Ative GitHub Pages nas configurações (padrão: branch main / root).
3. Acesse https://SEU_USUARIO.github.io/NOME-REPO/

## Observações
- Código modular em arquivos separados.
- Sistema de templates simples para demonstrar renderização dinâmica via JS.
- Validação de formulários com aviso visual e mensagens de erro.
